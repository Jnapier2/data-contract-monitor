"""Bundled static dashboard assets."""
